import { ProfileHeader } from '@/components/profile/profile-header'
import { SocialGrid } from '@/components/profile/social-grid'
import { ContactCard } from '@/components/profile/contact-card'
import { LocationCard } from '@/components/profile/location-card'
import { profile } from '@/lib/profile'

export default function Page() {
  return (
    <div className="relative min-h-dvh overflow-hidden bg-background">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0">
        <div className="absolute -left-40 -top-40 size-[30rem] rounded-full bg-primary/20 blur-[130px]" />
        <div className="absolute -right-32 top-1/3 size-[26rem] rounded-full bg-accent/15 blur-[130px]" />
        <div className="absolute -bottom-40 left-1/4 size-[28rem] rounded-full bg-highlight/15 blur-[130px]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,oklch(0.86_0.22_150/0.06)_1px,transparent_1px),linear-gradient(to_bottom,oklch(0.86_0.22_150/0.06)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_top,black_20%,transparent_70%)]" />
        <div className="absolute inset-0 bg-[repeating-linear-gradient(to_bottom,transparent_0px,transparent_3px,oklch(0_0_0/0.18)_4px)]" />
      </div>

      <main className="relative mx-auto flex w-full max-w-xl flex-col gap-7 px-5 py-12 sm:py-16">
        <ProfileHeader />
        <ContactCard />
        <SocialGrid />
        <LocationCard />
        <footer className="pt-2 text-center font-mono text-xs text-muted-foreground">
          <span className="text-primary">{'>'}</span>
          {` © ${new Date().getFullYear()} ${profile.fullName} · system online`}
        </footer>
      </main>
    </div>
  )
}
