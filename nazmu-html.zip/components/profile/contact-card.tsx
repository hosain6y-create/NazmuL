'use client'

import { Phone, UserPlus } from 'lucide-react'
import { FaWhatsapp } from 'react-icons/fa6'
import { profile } from '@/lib/profile'

function downloadVCard() {
  const vcard = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${profile.fullName}`,
    `TITLE:${profile.title}`,
    `TEL;TYPE=CELL:${profile.phone}`,
    `ADR;TYPE=HOME:;;Phultala;Khulna;;;Bangladesh`,
    'END:VCARD',
  ].join('\n')
  const blob = new Blob([vcard], { type: 'text/vcard' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `${profile.fullName.replace(/\s+/g, '-')}.vcf`
  link.click()
  URL.revokeObjectURL(url)
}

const actionBase =
  'flex flex-col items-center justify-center gap-1.5 rounded-2xl border px-2 py-4 text-xs font-semibold transition-all hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring'

export function ContactCard() {
  return (
    <section aria-label="Quick actions" className="grid grid-cols-3 gap-3">
      <a
        href={`tel:${profile.phone}`}
        className={`${actionBase} border-primary/50 bg-primary text-primary-foreground shadow-[0_10px_30px_-10px_var(--primary)]`}
      >
        <Phone className="size-5" aria-hidden="true" />
        Call
      </a>
      <a
        href="https://wa.me/8801626083895"
        target="_blank"
        rel="noopener noreferrer"
        className={`${actionBase} border-[#25D366]/40 bg-[#25D366]/10 text-[#25D366] hover:bg-[#25D366]/20`}
      >
        <FaWhatsapp className="size-5" aria-hidden="true" />
        WhatsApp
        <span className="sr-only">(opens in a new tab)</span>
      </a>
      <button
        type="button"
        onClick={downloadVCard}
        className={`${actionBase} border-highlight/40 bg-highlight/10 text-highlight hover:bg-highlight/20`}
      >
        <UserPlus className="size-5" aria-hidden="true" />
        Save
      </button>
    </section>
  )
}
