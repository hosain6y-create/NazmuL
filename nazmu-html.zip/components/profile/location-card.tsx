import { MapPin, Navigation } from 'lucide-react'
import { profile } from '@/lib/profile'

export function LocationCard() {
  const query = encodeURIComponent(profile.mapQuery)

  return (
    <section
      aria-labelledby="location-heading"
      className="overflow-hidden rounded-3xl border border-border bg-card/60 backdrop-blur-md"
    >
      <div className="flex items-center gap-4 p-5">
        <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-highlight/15 text-highlight ring-1 ring-highlight/40 shadow-[0_0_24px_-6px_var(--highlight)]">
          <MapPin className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <h2
            id="location-heading"
            className="font-mono text-[11px] font-semibold uppercase tracking-[0.3em] text-muted-foreground"
          >
            Location
          </h2>
          <p className="font-semibold text-foreground">{profile.location}</p>
        </div>
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${query}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-highlight/40 bg-highlight/10 px-3 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-highlight transition-colors hover:bg-highlight hover:text-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Navigation className="size-3.5" aria-hidden="true" />
          Go
          <span className="sr-only">(opens Google Maps in a new tab)</span>
        </a>
      </div>
      <div className="relative h-52 border-t border-border">
        <iframe
          title={`Map showing ${profile.location}`}
          src={`https://maps.google.com/maps?q=${query}&z=13&output=embed`}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          className="size-full invert-[92%] hue-rotate-[160deg] saturate-[0.8] contrast-[0.95]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 shadow-[inset_0_0_60px_oklch(0.12_0.02_165)]"
        />
      </div>
    </section>
  )
}
