import Image from 'next/image'
import { BadgeCheck, MapPin } from 'lucide-react'
import { profile } from '@/lib/profile'
import { ShareButton } from './share-button'

export function ProfileHeader() {
  return (
    <header className="flex flex-col items-center text-center">
      <span className="mb-8 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.25em] text-primary shadow-[0_0_24px_-6px_var(--primary)]">
        <span className="relative flex size-2">
          <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75" />
          <span className="relative inline-flex size-2 rounded-full bg-primary" />
        </span>
        Connected &amp; Active
      </span>

      <div className="relative">
        <div
          aria-hidden="true"
          className="absolute -inset-2 animate-[spin_6s_linear_infinite] rounded-[2rem] bg-[conic-gradient(from_0deg,var(--primary),var(--accent),var(--highlight),var(--primary))] opacity-90 blur-[3px]"
        />
        <div className="relative size-36 overflow-hidden rounded-[1.75rem] border-4 border-background bg-background sm:size-40">
          <Image
            src={profile.avatar || '/placeholder.svg'}
            alt={`${profile.name} hacker avatar`}
            width={320}
            height={320}
            priority
            className="size-full object-cover"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-[repeating-linear-gradient(to_bottom,transparent_0px,transparent_2px,oklch(0_0_0/0.25)_3px)]"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 h-10 animate-scan bg-gradient-to-b from-transparent via-primary/30 to-transparent"
          />
        </div>
        {(['-left-4 -top-4 border-l-2 border-t-2', '-right-4 -top-4 border-r-2 border-t-2', '-bottom-4 -left-4 border-b-2 border-l-2', '-bottom-4 -right-4 border-b-2 border-r-2'] as const).map(
          (pos) => (
            <span
              key={pos}
              aria-hidden="true"
              className={`absolute size-5 border-primary ${pos}`}
            />
          ),
        )}
      </div>

      <h1 className="mt-8 flex items-center gap-2 font-mono text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
        <span className="bg-gradient-to-r from-primary via-accent to-highlight bg-clip-text text-transparent drop-shadow-[0_0_18px_oklch(0.86_0.22_150/0.35)]">
          {profile.name}
        </span>
        <BadgeCheck className="size-7 text-accent" aria-label="Verified" />
      </h1>

      <p className="mt-3 font-mono text-sm text-muted-foreground">
        <span className="text-primary">{'root@nazmul'}</span>
        <span className="text-foreground/60">{':~$ '}</span>
        <span className="text-foreground">{profile.title}</span>
        <span aria-hidden="true" className="ml-1 inline-block h-4 w-2 translate-y-0.5 animate-blink bg-primary" />
      </p>

      <p className="mt-4 max-w-sm text-pretty leading-relaxed text-muted-foreground">
        {profile.bio}
      </p>

      <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3 py-1.5 text-xs font-medium text-foreground backdrop-blur">
          <MapPin className="size-3.5 text-highlight" aria-hidden="true" />
          {profile.location}
        </span>
        <ShareButton />
      </div>
    </header>
  )
}
