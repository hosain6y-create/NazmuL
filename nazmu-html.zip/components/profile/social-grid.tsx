'use client'

import { useState } from 'react'
import type { IconType } from 'react-icons'
import {
  FaDiscord,
  FaFacebookF,
  FaInstagram,
  FaPhone,
  FaTelegram,
  FaTiktok,
  FaWhatsapp,
  FaXTwitter,
} from 'react-icons/fa6'
import { Check, Copy } from 'lucide-react'
import { socials, type SocialKey, type SocialLink } from '@/lib/profile'

const icons: Record<SocialKey, IconType> = {
  whatsapp: FaWhatsapp,
  phone: FaPhone,
  telegram: FaTelegram,
  facebook: FaFacebookF,
  instagram: FaInstagram,
  twitter: FaXTwitter,
  tiktok: FaTiktok,
  discord: FaDiscord,
}

function SocialRow({ social, index }: { social: SocialLink; index: number }) {
  const [copied, setCopied] = useState(false)
  const Icon = icons[social.key]
  const isExternal = social.url.startsWith('http')

  async function copyHandle() {
    await navigator.clipboard.writeText(social.handle)
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  return (
    <li
      className="animate-in fade-in slide-in-from-bottom-3 fill-mode-both duration-500"
      style={{ animationDelay: `${index * 60}ms`, '--brand': social.color } as React.CSSProperties}
    >
      <div className="group relative flex items-center gap-4 overflow-hidden rounded-2xl border border-border bg-card/60 p-3.5 pr-3 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:border-[var(--brand)]/50 hover:shadow-[0_12px_40px_-14px_var(--brand)]">
        <span
          aria-hidden="true"
          className="absolute inset-y-3 left-0 w-[3px] rounded-r-full bg-[var(--brand)] opacity-70 shadow-[0_0_12px_var(--brand)] transition-opacity group-hover:opacity-100"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_0%_50%,var(--brand),transparent_55%)] opacity-[0.07] transition-opacity duration-300 group-hover:opacity-20"
        />

        <span className="relative ml-1 flex size-12 shrink-0 items-center justify-center rounded-xl bg-[var(--brand)]/12 text-[var(--brand)] ring-1 ring-[var(--brand)]/30 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-[-6deg]">
          <Icon className="size-5" aria-hidden="true" />
        </span>

        <span className="relative flex min-w-0 flex-1 flex-col">
          <span className="font-semibold text-foreground">{social.label}</span>
          <span className="truncate font-mono text-sm text-muted-foreground">{social.handle}</span>
        </span>

        <button
          type="button"
          onClick={copyHandle}
          aria-label={copied ? `${social.label} copied` : `Copy ${social.label} handle`}
          className="relative flex size-9 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-[var(--brand)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
        </button>

        <a
          href={social.url}
          {...(isExternal ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
          className="relative shrink-0 rounded-lg border border-[var(--brand)]/40 bg-[var(--brand)]/10 px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-[var(--brand)] transition-all hover:bg-[var(--brand)] hover:text-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          {social.action}
          <span className="sr-only">
            {` ${social.label}`}
            {isExternal ? ' (opens in a new tab)' : ''}
          </span>
        </a>
      </div>
    </li>
  )
}

export function SocialGrid() {
  return (
    <section aria-labelledby="socials-heading">
      <div className="mb-4 flex items-center gap-3">
        <h2
          id="socials-heading"
          className="font-mono text-xs font-semibold uppercase tracking-[0.3em] text-primary"
        >
          {'// Connect'}
        </h2>
        <span aria-hidden="true" className="h-px flex-1 bg-gradient-to-r from-primary/50 to-transparent" />
        <span className="font-mono text-xs text-muted-foreground">{`${socials.length} links`}</span>
      </div>
      <ul className="flex flex-col gap-3">
        {socials.map((social, index) => (
          <SocialRow key={social.key} social={social} index={index} />
        ))}
      </ul>
    </section>
  )
}
