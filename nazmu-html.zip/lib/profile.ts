export const profile = {
  name: 'NazmuL',
  fullName: 'NazmuL Hosain',
  handle: 'h4nazmul',
  title: 'Creator · Developer · Digital Explorer',
  bio: 'Turning ideas into code. Reach me on any platform below — fastest reply on WhatsApp & Telegram.',
  avatar: '/images/avatar-hacker.png',
  phone: '+8801626083895',
  phoneDisplay: '+880 1626-083895',
  location: 'Phultala, Khulna, Bangladesh',
  mapQuery: 'Phultala, Khulna, Bangladesh',
}

export type SocialKey =
  | 'whatsapp'
  | 'phone'
  | 'telegram'
  | 'facebook'
  | 'instagram'
  | 'twitter'
  | 'tiktok'
  | 'discord'

export type SocialLink = {
  key: SocialKey
  label: string
  handle: string
  url: string
  action: string
  color: string
}

export const socials: SocialLink[] = [
  {
    key: 'whatsapp',
    label: 'WhatsApp',
    handle: profile.phoneDisplay,
    url: 'https://wa.me/8801626083895',
    action: 'Chat',
    color: '#25D366',
  },
  {
    key: 'phone',
    label: 'Direct Call',
    handle: profile.phoneDisplay,
    url: `tel:${profile.phone}`,
    action: 'Call',
    color: '#34F5A5',
  },
  {
    key: 'telegram',
    label: 'Telegram',
    handle: '@ns660',
    url: 'https://t.me/ns660',
    action: 'Connect',
    color: '#2AABEE',
  },
  {
    key: 'facebook',
    label: 'Facebook',
    handle: 'nazmul8111',
    url: 'https://facebook.com/nazmul8111',
    action: 'Visit',
    color: '#1877F2',
  },
  {
    key: 'instagram',
    label: 'Instagram',
    handle: 'nazmul.h.4',
    url: 'https://instagram.com/nazmul.h.4',
    action: 'Follow',
    color: '#F2457F',
  },
  {
    key: 'twitter',
    label: 'Twitter (X)',
    handle: '@h4nazmul',
    url: 'https://x.com/h4nazmul',
    action: 'View',
    color: '#E7E9EA',
  },
  {
    key: 'tiktok',
    label: 'TikTok',
    handle: '@nazmu.ll',
    url: 'https://www.tiktok.com/@nazmu.ll',
    action: 'Watch',
    color: '#25F4EE',
  },
  {
    key: 'discord',
    label: 'Discord',
    handle: 'nazmu.l',
    url: 'https://discord.com/app',
    action: 'Join',
    color: '#7B83FF',
  },
]
